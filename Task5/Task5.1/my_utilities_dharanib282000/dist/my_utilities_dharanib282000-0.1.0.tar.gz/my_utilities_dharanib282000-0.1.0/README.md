# My Utilities

A collection of utility functions for various tasks, including mathematical operations, string processing, and file handling.

## Installation

To install this package, use:

```bash
pip install my_utilities
